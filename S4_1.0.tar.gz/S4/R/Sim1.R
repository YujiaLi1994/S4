##' Function to simulate data for 10 settings in simulation1
##' @title Function to simulate data for 10 settings in simulation1   
##' @param settings Simulate setting from 1 to 10 corresponding to the simulation1 in S4 paper.
 

##' @return The data matrix corresponding to each setting

##' @export
##' @examples
##' \dontrun{
##' Sim1(settings="2")
##' }



Sim1<-function(settings="1"){
  if(settings=="1"){
    x = matrix(runif(2000),ncol = 10)
    return(x)
  }
  if(settings=="2"){
    x = rbind(matrix(rnorm(50),ncol = 2),
              matrix(c(rnorm(25),(rnorm(25)+5)),ncol = 2),#+5
              matrix(c(rnorm(50)+5,rnorm(50)-3),ncol = 2))#-3
    return(x)
  }
  if(settings=="3"){
    minm = 0
    while(minm < 1){
      centers = mvrnorm(n = 4, mu = rep(0,3), Sigma = 5*diag(3))
      m1 = matrix(rnorm(3*sample(c(25,50),1)),ncol = 3)
      m1 <- t(apply(m1, 1, function(x) x+centers[1,]))
      m2 = matrix(rnorm(3*sample(c(25,50),1)),ncol = 3)
      m2 <- t(apply(m2, 1, function(x) x+centers[2,]))
      m3 = matrix(rnorm(3*sample(c(25,50),1)),ncol = 3)
      m3 <- t(apply(m3, 1, function(x) x+centers[3,]))
      m4 = matrix(rnorm(3*sample(c(25,50),1)),ncol = 3)
      m4 <- t(apply(m4, 1, function(x) x+centers[4,]))
      m <- as.matrix(dist(rbind(m1,m2,m3,m4)))
      m[1:nrow(m1),1:nrow(m1)] <- 1000
      m[(nrow(m1)+1):(nrow(m1)+nrow(m2)),(nrow(m1)+1):(nrow(m1)+nrow(m2))] <- 1000
      m[(nrow(m1)+nrow(m2)+1):(nrow(m1)+nrow(m2)+nrow(m3)),
        (nrow(m1)+nrow(m2)+1):(nrow(m1)+nrow(m2)+nrow(m3))] <- 1000
      m[(nrow(m1)+nrow(m2)+nrow(m3)+1):(nrow(m1)+nrow(m2)+nrow(m3)+nrow(m4)),
        (nrow(m1)+nrow(m2)+nrow(m3)+1):(nrow(m1)+nrow(m2)+nrow(m3)+nrow(m4))] <- 1000
      minm <- min(m)
      x = rbind(m1,m2,m3,m4)
    }
    return(x)
  }
  if(settings=="4"){
    minm = 0
    while(minm < 1){
      centers = mvrnorm(n = 4, mu = rep(0,10), Sigma = 1.9*diag(10))
      m1 = matrix(rnorm(10*sample(c(25,50),1)),ncol = 10)
      m1 <- t(apply(m1, 1, function(x) x+centers[1,]))
      m2 = matrix(rnorm(10*sample(c(25,50),1)),ncol = 10)
      m2 <- t(apply(m2, 1, function(x) x+centers[2,]))
      m3 = matrix(rnorm(10*sample(c(25,50),1)),ncol = 10)
      m3 <- t(apply(m3, 1, function(x) x+centers[3,]))
      m4 = matrix(rnorm(10*sample(c(25,50),1)),ncol = 10)
      m4 <- t(apply(m4, 1, function(x) x+centers[4,]))
      m <- as.matrix(dist(rbind(m1,m2,m3,m4)))
      m[1:nrow(m1),1:nrow(m1)] <- 1000
      m[(nrow(m1)+1):(nrow(m1)+nrow(m2)),(nrow(m1)+1):(nrow(m1)+nrow(m2))] <- 1000
      m[(nrow(m1)+nrow(m2)+1):(nrow(m1)+nrow(m2)+nrow(m3)),
        (nrow(m1)+nrow(m2)+1):(nrow(m1)+nrow(m2)+nrow(m3))] <- 1000
      m[(nrow(m1)+nrow(m2)+nrow(m3)+1):(nrow(m1)+nrow(m2)+nrow(m3)+nrow(m4)),
        (nrow(m1)+nrow(m2)+nrow(m3)+1):(nrow(m1)+nrow(m2)+nrow(m3)+nrow(m4))] <- 1000
      minm <- min(m)
      x = rbind(m1,m2,m3,m4)
    }
    return(x)
  }
  if(settings=="5"){
    x = rbind(matrix(c(seq(-0.5,0.5,length.out = 100)+rnorm(100,sd = 0.1),
                       seq(-0.5,0.5,length.out = 100)+rnorm(100,sd = 0.1),
                       seq(-0.5,0.5,length.out = 100)+rnorm(100,sd = 0.1)),ncol = 3),
              matrix(c(seq(-0.5,0.5,length.out = 100)+rnorm(100,sd = 0.1)+10,
                       seq(-0.5,0.5,length.out = 100)+rnorm(100,sd = 0.1)+10,
                       seq(-0.5,0.5,length.out = 100)+rnorm(100,sd = 0.1)+10),ncol = 3))
    return(x)
  }
  if(settings=="6"){
    x = rbind(matrix(rnorm(50),ncol = 2),
              matrix(c(rnorm(25),rnorm(25)+2.5),ncol = 2),
              matrix(c(rnorm(25)+2.5,rnorm(25)),ncol = 2),
              matrix(c(rnorm(25)+2.5,rnorm(25)+2.5),ncol = 2))
    return(x)
  }
  if(settings=="7"){
    x = rbind(matrix(rnorm(50),ncol = 2),
              matrix(c(rnorm(25),rnorm(25)+3),ncol = 2),
              matrix(c(rnorm(25)+3,rnorm(25)),ncol = 2),
              matrix(c(rnorm(25)+3,rnorm(25)+3),ncol = 2))
    return(x)
  }
  if(settings=="8"){
    x = rbind(matrix(rnorm(50),ncol = 2),
              matrix(c(rnorm(25),rnorm(25)+3.5),ncol = 2),
              matrix(c(rnorm(25)+3.5,rnorm(25)),ncol = 2),
              matrix(c(rnorm(25)+3.5,rnorm(25)+3.5),ncol = 2))
    return(x)
  }
  if(settings=="9"){
    x = rbind(matrix(c(seq(-0.5,0.5,length.out = 100)+rnorm(100,sd = 0.1),
                       seq(-0.5,0.5,length.out = 100)+rnorm(100,sd = 0.1),
                       seq(-0.5,0.5,length.out = 100)+rnorm(100,sd = 0.1)),ncol = 3),
              matrix(c(seq(-0.5,0.5,length.out = 100)+rnorm(100,sd = 0.1)+1,
                       seq(-0.5,0.5,length.out = 100)+rnorm(100,sd = 0.1)+1,
                       seq(-0.5,0.5,length.out = 100)+rnorm(100,sd = 0.1)+1),ncol = 3))
    return(x)
  }
  if(settings=="10"){
    x = rbind(matrix(c(seq(-0.5,0.5,length.out = 100)+rnorm(100,sd = 0.1),
                       seq(-0.5,0.5,length.out = 100)+rnorm(100,sd = 0.1),
                       seq(-0.5,0.5,length.out = 100)+rnorm(100,sd = 0.1)),ncol = 3),
              matrix(c(seq(-0.5,0.5,length.out = 100)+rnorm(100,sd = 0.1)+1,
                       seq(-0.5,0.5,length.out = 100)+rnorm(100,sd = 0.1),
                       seq(-0.5,0.5,length.out = 100)+rnorm(100,sd = 0.1)),ncol = 3))
    return(x)
  }
}
