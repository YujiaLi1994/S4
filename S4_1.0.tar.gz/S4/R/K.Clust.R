##' Estimate number of clusters for K-Means
##' @title Estimate number of clusters for K-Means
##' @param data A matrix where rows represent samples and columns represent features
##' @param method Method to use, including all the methods compared in S4 paper. Please refer to the reference of S4 paper
##' \itemize{
##' \item{"S4": }{Manuscript: Simultaneous Estimation of Number of Clusters and Feature Sparsity in Clustering High-Dimensional Data Using Resampling.}
##' \item{"Gap.PCA", "Gap.Unif": }{Tibshirani, R., Walther, G., and Hastie, T. (2001).}
##' \item{"PS": }{Tibshirani, R. and Walther, G. (2005). }
##' \item{"Jump": }{Sugar, C. A. and James, G. M. (2003)}
##' \item{"CH": }{Calinski, T. and Harabasz, J. (1974)}
##' \item{"FW": }{Fang, Y. and Wang, J. (2012)}
##' \item{"LD": }{Levine, E. and Domany, E. (2001).}
##' \item{"KL": }{Krzanowski, W. J. and Lai, Y. (1988).}
##' \item{"H": }{Hartigan, J. A. (1975). }
##' \item{"silhouette": }{Rousseeuw, P. J. (1987).}
##' }
##' @param Kmin integer. Minimum number of clusters
##' @param Kmax=10 integer. Maximum number of clusters.
##' @param trim.S4 The precentage of trim for S4 method
##' @param cutoff The threshold for detecting null cluster structure for resampling-based methods. If score is smaller than cutoff, return one cluster.
##' @param n.resample Number of resamples in resampling-based methods. Also for Gap statistic, n.resample means the number of reference data to generate.

##' @return The optimal number of clusters
##' @references S4: Manuscript: Simultaneous Estimation of Number of Clusters and Feature Sparsity in Clustering High-Dimensional Data Using Resampling.
##'
##' "Gap.PCA" and "Gap.Unif": Tibshirani, R., Walther, G., and Hastie, T. (2001). Estimating the number of clusters in a data set via the gap statistic. Journal of the Royal Statistical Society: Series B (Statistical Methodology), 63(2):411-423.
##'
##' "PS":  Tibshirani, R. and Walther, G. (2005). Cluster validation by prediction strength. Journal of Computational and Graphical Statistics, 14(3):511-528.
##'
##' "Jump":  Sugar, C. A. and James, G. M. (2003). Finding the number of clusters in a dataset: An informationtheoretic approach. Journal of the American Statistical Association, 98(463):750-763.
##'
##' "CH":  Calinski, T. and Harabasz, J. (1974). A dendrite method for cluster analysis. Communications in Statistics-theory and Methods, 3(1):1-27.
##'
##' "FW":  Fang, Y. and Wang, J. (2012). Selection of the number of clusters via the bootstrap method. Computational Statistics & Data Analysis, 56(3):468-477.
##'
##' "LD":  Levine, E. and Domany, E. (2001). Resampling method for unsupervised estimation of cluster validity. Neural computation, 13(11):2573{2593.
##'
##' "KL":  Krzanowski, W. J. and Lai, Y. (1988). A criterion for determining the number of groups in a dataset using sum-of-squares clustering. Biometrics, pages 23-34.
##'
##' "H":  Hartigan, J. A. (1975). Clustering algorithms, new york: John willey and sons. Inc. Pages113129.}
##'
##' "silhouette":  Rousseeuw, P. J. (1987). Silhouettes: a graphical aid to the interpretation and validation of cluster analysis. Journal of computational and applied mathematics, 20:53-65.
##' @export
##' @examples
##' \dontrun{
##' n.resample=25
##' x1<-Sim1(settings="2")
##' res.S4 <- K.Clust(x1,method="S4",Kmin=2,Kmax=10)
##' }




K.Clust<-function(data,method="S4",Kmin=2,Kmax=10,trim.S4=0.05,cutoff=0.8,n.resample=50){
  #method_list:(Gap.PCA, Gap.Unif, Jump, CH, KL, H, silhouette, PS, FW, LD, S4)
  #NBclust give more than 20 indice, For detail of index, please look at NBclust package, here we only consider 4 index method.
  if(method=="S4"){
    result.S4 <- S4(data,K.try = Kmin:Kmax,n.resample=n.resample,trim=trim.S4,cut.off=cutoff)
    return(result.S4)
  }
  if(method=="Gap.PCA"){
    gapst_pca <- clusGap(data, FUN = kmeans, nstart = 100, K.max = 10, B =n.resample,spaceH0 ="scaledPCA")
    gaprs_pca <- with(gapst_pca,maxSE(Tab[,"gap"],Tab[,"SE.sim"]))
    return(gaprs_pca)
  }
  if(method=="Gap.Unif"){
    gapst_Unif <- clusGap(data, FUN = kmeans, nstart = 100, K.max = Kmax, B = n.resample,spaceH0 ="scaledPCA")
    gaprs_Unif <- with(gapst_Unif,maxSE(Tab[,"gap"],Tab[,"SE.sim"]))
    return(gaprs_Unif)
  }
  if(method=="PS"){
    ps <- prediction.strength(data,Gmin=Kmin,Gmax=Kmax,M=n.resample,cutoff=cutoff)
    ps <- ps$optimalk
    return(ps)
  }
  if(method=="Jump"){
    jm = jump(data,K=Kmax)$maxjump
    return(jm)
  }
  if(method=="CH"){
    CH<-cluster_CH(data,K.try=Kmin:Kmax)
    return(CH)
  }
  if(method=="FW"){
    rboot<-nselectboot(data,B=n.resample,clustermethod=kmeansCBI,krange=Kmin:Kmax)$kopt
    return(rboot)
  }
  if(method=="LD"){
    re_sens<-resample_sensitivity(data, K.try = Kmin:Kmax,n.resample=n.resample,cut.off = cutoff)
    return(re_sens)
  }
  if(method=="KL"){
    KL<-NBClust1(data=data,min.nc = Kmin, max.nc = Kmax,method="kmeans",index="kl")$Best.nc[1]
    return(KL)
  }
  if(method=="H"){
    H<-hartigan1(data,min.nc =Kmin,max.nc = Kmax)
    return(H)
  }
  if(method=="silhouette"){
    Sil<-NBClust1(data=data,min.nc = Kmin, max.nc = Kmax,method="kmeans",index="silhouette")$Best.nc[1]
    return(Sil)
  }


}
