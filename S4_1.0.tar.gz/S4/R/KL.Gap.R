##' Estimate number of clusters and sparsity parameter simultaneously by extended gap statistic.
##' @title Estimate number of clusters and sparsity parameter simultaneously by extended gap statistic.
##' @param x data matrix, where rows represent samples and columns represents features
##' @param lambda_list a list whose length is equal to k_vector. Every element is a vector of lambda
##' as the search region for this K.
##' @param k_vector The search pool for number of clusters
##' @param n.perms Number of permutated data generated
##' @param num_cores Number of cpus used in parallel computing. It is suggest to run large num_cores
##' in servers instead of laptops.
##' @return A list of two components:
##' \itemize{
##' \item{res_k: }{Optimal number of clusters}
##' \item{res_w: }{Optimal lambda}
##'
##' }
##' @references Estimating the number of clusters in a data set via the gap statistic. Journal of the Royal Statistical Society: Series B (Statistical Methodology),63(2):411-423.
##'
##' Witten, D. M. and Tibshirani, R. (2010). A framework for feature selection in clustering. Journal of the American Statistical Association, 105(490):713-726.
##'
##' @export
##' @examples
##' \dontrun{
##'data(data_tanbin_mat)
##'data<-RatBrain$data
##'k_vector=c(2,3,4)

##'########get lambda list
##'lambda_list<-mclapply(1:length(k_vector),function(i){
##'  K<-k_vector[i]
##'  error = T
##'  ind<-0
##'  while(error){
##'    result= tryCatch(region.lambda(iteration=40,x=data,K=K), error = function(x) NA)
##'    if(!is.na(result[1])){
##'      error = F
##'    }
##'    ind<-ind+1
##'    if(ind>3){break}
##'  }
##'  return(result)
##'
##'},mc.cores = 1)
##'########avoid the extremly large lambda which is likely to choose all the features.
##'for(l in 1:length(k_vector)){
##'  temp<-KMeansSparseCluster(data,K=k_vector[l],wbounds=lambda_list[[l]],nstart=100)
##'  num<-rep(0,length(temp))
##'  for(i in 1:length(num)){
##'    num[i]<-sum(temp[[i]]$ws>0)
##'  }
##'  if(sum(num==ncol(data))>0){
##'    lambda_list[[l]]<-lambda_list[[l]][1:(min(which(num==ncol(data)))-3)]
##'  }
##'}
##'KL.Gap(data,k_vector=k_vector,lambda_list,n.perms=25,num_cores=1)
##' }




KL.Gap<-function(x,k_vector=c(2,3,4),lambda_list,n.perms=25,num.cores=1){
  res_gap<-list(1)
  res_gap_sd<-list(1)
  res = mclapply(1:length(k_vector),function(l){
    a = KmeansSparseCluster.permute1(x, K=k_vector[l], nperms = n.perms, wbounds = lambda_list[[l]],
                                     silent = FALSE, nvals = 20, centers=NULL)
    return(list(gap=a$gaps,sd=a$sdgaps))
  },mc.cores = num_cores)


  for(i in 1:length(res)){
    res_gap[[i]]<-res[[i]]$gap
    res_gap_sd[[i]]<-res[[i]]$sd
  }


  maxgap_k<-rep(-1,length(k_vector))
  for(i in 1:length(k_vector)){
    maxgap_k[i]<-max(res_gap[[i]])
  }
  gap_k<-k_vector[max(which(max(maxgap_k)==maxgap_k))]
  #a<-KmeansSparseCluster.permute1(x, K=gap_k, nperms = n.perms, wbounds = lambda_list[[which(k_vector==gap_k)]],
  #                                silent = FALSE, nvals = 20, centers=NULL)
  #maxgap_minus_sd<-max(a$gaps)-a$sdgaps[which.max(a$gaps)]
  a<-res_gap[[which(k_vector==gap_k)]]
  maxgap_minus_sd<-max(a)-res_gap_sd[[which(k_vector==gap_k)]][which.max(a)]
  res_w<-lambda_list[[which(k_vector==gap_k)]][which.max(a>maxgap_minus_sd)]
  return(list(res_k=gap_k,res_w=res_w))
}
