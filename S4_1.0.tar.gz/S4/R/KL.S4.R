##' Estimate number of clusters and sparsity parameter simultaneously by S4.
##' @title Estimate number of clusters and sparsity parameter simultaneously by S4.
##' @param x data matrix, where rows represent samples and columns represents features
##' @param lambda_list a list whose length is equal to k_vector. Every element is a vector of lambda
##' as the search region for this K.
##' @param k_vector The search pool for number of clusters
##' @param trim Percentage of trim by S4 method.
##' @param n.resample Number of subsampling, Usually needed to be larger than 20
##' @param num.cores Number of cpus used in parallel computing. It is suggest to run large num_cores
##' in servers instead of laptops.
##' @return A list of two components:
##' \itemize{
##' \item{clus_score: }{Cluster stability score for every K and lambda.}
##' \item{final_score: }{The average of cluster stability score and feature stability
##' score for every K and lambda}
##' \item{optimal_k: }{Optimal number of clusters}
##' \item{optimal_lambda: }{Optimal lambda}
##' }
##' @export
##' @examples
##' \dontrun{
##'data(data_tanbin_mat)
##'data<-RatBrain$data
##'k_vector=c(2,3,4)

##'########get lambda list
##'lambda_list<-mclapply(1:length(k_vector),function(i){
##'  K<-k_vector[i]
##'  error = T
##'  ind<-0
##'  while(error){
##'    result= tryCatch(region.lambda(iteration=40,x=data,K=K), error = function(x) NA)
##'    if(!is.na(result[1])){
##'      error = F
##'    }
##'    ind<-ind+1
##'    if(ind>3){break}
##'  }
##'  return(result)
##'
##'},mc.cores = 1)
##'########avoid the extremly large lambda which is likely to choose all the features.
##'for(l in 1:length(k_vector)){
##'  temp<-KMeansSparseCluster(data,K=k_vector[l],wbounds=lambda_list[[l]],nstart=100)
##'  num<-rep(0,length(temp))
##'  for(i in 1:length(num)){
##'    num[i]<-sum(temp[[i]]$ws>0)
##'  }
##'  if(sum(num==ncol(data))>0){
##'    lambda_list[[l]]<-lambda_list[[l]][1:(min(which(num==ncol(data)))-3)]
##'  }
##'}

##'KL.S4(data, lambda_list,trim=0.05,k_vector=k_vector,n.resample=25,num.cores=1)
##' }




KL.S4 = function(x, lambda_list,trim=0.05,k_vector=c(2,3,4),n.resample=25,num.cores=1){
  result_clus<-list(1)
  result_final<-list(1)
  for(ind_k in 1:length(k_vector)){
    k<-k_vector[ind_k]
    lambda_vector<-lambda_list[[ind_k]]
    wcs = mclapply(1:length(lambda_vector),function(ind_lambda,k,x){
      lambda<-lambda_vector[ind_lambda]
      error = T
      ind<-0
      while(error){
        result= tryCatch(score_lambda(lambda,x,k,trim=0.05,n.resample=n.resample), error = function(x) NA)
        if(!is.na(result[1])){
          error = F
        }
        ind<-ind+1
        if(ind>3){break}
      }


      #result<-score_lambda(lambda,x,k,trim=0.05,n.resample=25)
      return(result)
    },k = k,x=x,mc.cores = num.cores)
    result_clus[[ind_k]]<-NA
    result_final[[ind_k]]<-NA
    for(ind_lambda in 1:length(lambda_vector)){
      result_clus[[ind_k]][ind_lambda]<-wcs[[ind_lambda]]$clus_score
      result_final[[ind_k]][ind_lambda]<-wcs[[ind_lambda]]$final_score
    }
  }
  result_k<-rep(-1,length(k_vector))
  for(i in 1:length(k_vector)){
    result_k[i]<-max(result_clus[[i]])
  }
  res_k<-k_vector[max(which(result_k==max(result_k)))]
  index<-which.max(result_final[[which(res_k==k_vector)]])
  res_lambda<-lambda_list[[which(res_k==k_vector)]][index]
  return(list(clus_score=result_clus,final_score=result_final,optimal_k=res_k,optimal_lambda=res_lambda))
}
