##' Estimate number of clusters and sparsity parameter simultaneously by extended prediction strength.
##' @title Estimate number of clusters and sparsity parameter simultaneously by extended prediction strength.
##' @param x data matrix, where rows represent samples and columns represents features
##' @param lambda_list a list whose length is equal to k_vector. Every element is a vector of lambda
##' as the search region for this K.
##' @param k_vector The search pool for number of clusters
##' @param cv Number of cross validation to do in each resampling. cv=2 is suggested by
##' Tibshirani, R. and Walther, G. (2005)
##' @param M Number of resampling. Every resampling is to divide the data into train and half.
##' @param num_cores Number of cpus used in parallel computing. It is suggest to run large num_cores
##' in servers instead of laptops.
##' @return A list of two components:
##' \itemize{
##' \item{res_k: }{Optimal number of clusters}
##' \item{res_w: }{Optimal lambda}
##'
##' }
##' @references Tibshirani, R. and Walther, G. (2005). Cluster validation by prediction strength. Journal of Computational and Graphical Statistics, 14(3):511-528.
##' @export
##' @examples
##' \dontrun{
##'data(data_tanbin_mat)
##'data<-RatBrain$data
##'k_vector=c(2,3,4)

##'########get lambda list
##'lambda_list<-mclapply(1:length(k_vector),function(i){
##'  K<-k_vector[i]
##'  error = T
##'  ind<-0
##'  while(error){
##'    result= tryCatch(region.lambda(iteration=40,x=data,K=K), error = function(x) NA)
##'    if(!is.na(result[1])){
##'      error = F
##'    }
##'    ind<-ind+1
##'    if(ind>3){break}
##'  }
##'  return(result)
##'
##'},mc.cores = 1)
##'########avoid the extremly large lambda which is likely to choose all the features.
##'for(l in 1:length(k_vector)){
##'  temp<-KMeansSparseCluster(data,K=k_vector[l],wbounds=lambda_list[[l]],nstart=100)
##'  num<-rep(0,length(temp))
##'  for(i in 1:length(num)){
##'    num[i]<-sum(temp[[i]]$ws>0)
##'  }
##'  if(sum(num==ncol(data))>0){
##'    lambda_list[[l]]<-lambda_list[[l]][1:(min(which(num==ncol(data)))-3)]
##'  }
##'}
##'KL.PS(data,lambda_list,cv=2,k_vector=k_vector,M=20,num_cores=1)
##' }





KL.PS<-function(x,lambda_list,cv=2,k_vector=c(2,3,4),M=20,num_cores=1){
  #n = nrow(x)
  result_final<-list(1)
  for(i in 1:length(k_vector)){
    K<-k_vector[i]

    temp<-rep(NA,length(lambda_list[[i]]))
    for(j in 1:length(lambda_list[[i]])){
      wbounds<-lambda_list[[i]][j]
      print(wbounds)
      #,num.cores=num_cores
      res<-mclapply(1:M,function(i1,cv,K,wbounds,x){
        error = T
        ind<-0
        while(error){
          result= tryCatch(score_PS(x,wbounds,K,cv), error = function(x) NA)
          result
          if(!is.na(result[1])){
            error = F
          }
          ind<-ind+1
          if(ind>3){break}
        }
        return(result)

      },cv=cv,K=K,wbounds=wbounds,x=x,mc.cores=num_cores)
      temp[j]<-mean(unlist(res))
    }
    result_final[[i]]<-temp


    #res.wbounds<-sapply(result, function(x) x$score)
  }
  # result_final<-lapply(1:length(k_vector),function(i){
  #
  # })
  #x_fold <- createFolds(1:n, k = cv, list = TRUE, returnTrain = FALSE)

  result_k<-rep(-1,length(k_vector))
  for(i in 1:length(k_vector)){
    result_k[i]<-max(unlist(result_final[[i]]))
  }
  res_k<-k_vector[max(which(result_k==max(result_k)))]
  index<-which.max(unlist(result_final[[max(which(result_k==max(result_k)))]]))
  res_w<-lambda_list[[max(which(result_k==max(result_k)))]][index]
  return(list(res_k=res_k,res_w=res_w))
}
